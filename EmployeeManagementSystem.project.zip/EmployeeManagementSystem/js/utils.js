/* ====================================================================
   EMS — SHARED UTILITIES
   Small, dependency-free helpers used by every other module.
   ==================================================================== */

const Utils = (() => {
  const HTML_ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

  /** Escape user-supplied text before putting it inside innerHTML. */
  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => HTML_ESCAPES[ch]);
  }

  /** 65000 -> "₹65,000" */
  function inr(value) {
    return "₹" + Math.round(Number(value) || 0).toLocaleString("en-IN");
  }

  function initials(name) {
    const letters = String(name || "")
      .trim()
      .split(/\s+/)
      .map((word) => word[0] || "")
      .join("")
      .slice(0, 2)
      .toUpperCase();
    return letters || "?";
  }

  /** Today's date as YYYY-MM-DD in the user's local timezone. */
  function today() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  /** "2026-03-12" -> "12 Mar 2026" */
  function formatDate(iso) {
    if (!iso) return "—";
    const d = new Date(iso + "T00:00:00");
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  }

  function greeting() {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  }

  /** Trigger a browser download of a text file. */
  function download(filename, text, mime = "text/plain") {
    const blob = new Blob([text], { type: mime + ";charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return { esc, inr, initials, today, formatDate, greeting, download };
})();
