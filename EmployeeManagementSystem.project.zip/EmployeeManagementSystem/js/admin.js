/* ====================================================================
   EMS — ADMIN DASHBOARD SCRIPT (admin.html)
   Guards the page (admin session required), then renders live numbers
   from the same EmployeeStore the main app uses.
   ==================================================================== */

(() => {
  "use strict";

  const session = Auth.getSession();
  if (!session || session.role !== "admin") {
    window.location.replace("admin-login.html");
    return;
  }

  const $ = (selector) => document.querySelector(selector);
  const { esc, inr, formatDate } = Utils;

  document.querySelectorAll("[data-admin-name]").forEach((el) => { el.textContent = session.name; });
  $("#adminGreeting").textContent = Utils.greeting();

  function render() {
    const report = Reports.summarize(EmployeeStore.all());
    const accounts = Auth.listAccounts();

    $("#aTotal").textContent = report.total;
    $("#aTotalNote").textContent = `${report.active} active · ${report.inactive} inactive`;
    $("#aDepts").textContent = report.departmentsInUse;
    $("#aDeptsNote").textContent = `of ${report.departments.length} departments in use`;
    $("#aPayroll").textContent = inr(report.activePayroll);
    $("#aPayrollNote").textContent = `Average ${inr(report.averageSalary)} per employee`;
    $("#aAccounts").textContent = accounts.length;
    $("#aAccountsNote").textContent = `${accounts.filter((a) => a.removable).length} self-registered`;

    $("#deptOverview").innerHTML = report.departments.map((d) => `
      <div class="activity-item">
        <div>
          <div class="activity-place">${esc(d.name)}</div>
          <div class="activity-detail">${d.count} employee${d.count === 1 ? "" : "s"} · avg ${inr(d.average)}</div>
        </div>
        <span class="activity-status ${d.count ? "" : "is-muted"}">${d.count ? d.active + " active" : "Empty"}</span>
      </div>`).join("");

    $("#recentHires").innerHTML = report.recent.length
      ? report.recent.map((e) => `
        <div class="activity-item">
          <div>
            <div class="activity-place">${esc(e.name)}</div>
            <div class="activity-detail">${esc(e.position)} · ${esc(e.department)} · joined ${esc(formatDate(e.joined))}</div>
          </div>
          <span class="activity-status ${e.status === "Active" ? "" : "is-muted"}">${esc(e.status)}</span>
        </div>`).join("")
      : `<p class="activity-empty">No employees yet.</p>`;

    $("#accountList").innerHTML = accounts.map((a) => `
      <div class="activity-item">
        <div>
          <div class="activity-place">${esc(a.name)}</div>
          <div class="activity-detail">${esc(a.email)} · ${esc(a.type)}</div>
        </div>
        ${a.removable ? `<button class="mini-btn" data-remove="${esc(a.email)}">Remove</button>` : ""}
      </div>`).join("");
  }

  $("#accountList").addEventListener("click", (event) => {
    const btn = event.target.closest("[data-remove]");
    if (!btn) return;
    if (window.confirm(`Remove the account ${btn.dataset.remove}? They will no longer be able to sign in.`)) {
      Auth.removeUser(btn.dataset.remove);
      render();
    }
  });

  $("#exportBtn").addEventListener("click", () => {
    Utils.download("employees-" + Utils.today() + ".csv", EmployeeStore.toCSV(), "text/csv");
  });

  $("#resetBtn").addEventListener("click", () => {
    if (window.confirm("Replace all employees with the 5 sample employees? This cannot be undone.")) {
      EmployeeStore.resetDemo();
      render();
    }
  });

  $("#logoutButton").addEventListener("click", () => {
    Auth.logout();
    window.location.href = "admin-login.html";
  });

  window.addEventListener("storage", render);
  render();
})();
