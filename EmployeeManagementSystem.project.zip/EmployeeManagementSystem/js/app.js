/* ====================================================================
   EMS — MAIN APPLICATION SCRIPT
   Orchestration only: state, rendering, event wiring.
   Data lives in storage.js, maths in reports.js, login in auth.js.
   ==================================================================== */

(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const { esc, inr, initials, formatDate } = Utils;

  const VIEWS = {
    dashboard: { title: "Dashboard", subtitle: "A quick overview of your workforce" },
    employees: { title: "Employees", subtitle: "Add, search, edit and manage your employees" },
    departments: { title: "Departments", subtitle: "Headcount and payroll for each department" },
    reports: { title: "Reports", subtitle: "Salary insights and data export" },
    settings: { title: "Settings", subtitle: "Appearance, account and data management" },
  };

  const state = { view: "dashboard", search: "", dept: "", status: "", sort: "name", editingId: null };

  // ==================== DOM REFERENCES ====================
  const dom = {
    gate: $("#authGate"),
    app: $("#emsApp"),
    pageTitle: $("#pageTitle"),
    pageSubtitle: $("#pageSubtitle"),
    userName: $("#userName"),
    userRole: $("#userRole"),
    userAvatar: $("#userAvatar"),
    adminLink: $("#adminLink"),

    statTotal: $("#statTotal"),
    statActive: $("#statActive"),
    statDepts: $("#statDepts"),
    statAverage: $("#statAverage"),
    deptBars: $("#deptBars"),
    donut: $("#statusDonut"),
    donutLabel: $("#donutLabel"),
    legendActive: $("#legendActive"),
    legendInactive: $("#legendInactive"),
    recentList: $("#recentList"),

    searchInput: $("#searchInput"),
    deptFilter: $("#departmentFilter"),
    statusFilter: $("#statusFilter"),
    sortSelect: $("#sortSelect"),
    resultCount: $("#resultCount"),
    employeeTable: $("#employeeTable"),

    deptGrid: $("#deptGrid"),

    repPayroll: $("#repPayroll"),
    repAverage: $("#repAverage"),
    repHighest: $("#repHighest"),
    repLowest: $("#repLowest"),
    repDeptBars: $("#repDeptBars"),
    repTop: $("#repTop"),

    setName: $("#setName"),
    setEmail: $("#setEmail"),
    setRole: $("#setRole"),
    themeSelect: $("#themeSelect"),

    modal: $("#employeeModal"),
    modalTitle: $("#modalTitle"),
    form: $("#employeeForm"),
    formError: $("#formError"),
    submitBtn: $("#submitBtn"),
    fId: $("#employeeId"),
    fName: $("#name"),
    fEmail: $("#email"),
    fDept: $("#department"),
    fPosition: $("#position"),
    fSalary: $("#salary"),
    fStatus: $("#status"),
    fJoined: $("#joined"),

    confirmModal: $("#confirmModal"),
    confirmTitle: $("#confirmTitle"),
    confirmText: $("#confirmText"),
    confirmOk: $("#confirmOk"),
    confirmCancel: $("#confirmCancel"),

    toast: $("#toast"),
  };

  let lastFocus = null;
  let toastTimer = null;

  // ==================== TOAST ====================
  function showToast(message) {
    dom.toast.textContent = message;
    dom.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => dom.toast.classList.remove("show"), 2600);
  }

  // ==================== AUTH GATE ====================
  function syncAuth(event) {
    const session = Auth.getSession();
    const allowed = session && (session.role === "user" || session.role === "admin");
    dom.gate.hidden = Boolean(allowed);
    dom.app.hidden = !allowed;
    document.body.style.overflow = allowed ? "" : "hidden";
    if (!allowed) return;

    dom.userName.textContent = session.name;
    dom.userRole.textContent = session.role === "admin" ? "Administrator" : "HR user";
    dom.userAvatar.textContent = initials(session.name);
    if (dom.adminLink) dom.adminLink.hidden = session.role !== "admin";
    dom.setName.textContent = session.name;
    dom.setEmail.textContent = session.email;
    dom.setRole.textContent = session.role === "admin" ? "Administrator" : "HR user";

    showView(viewFromHash());
    renderAll();
    if (event && event.detail && event.detail.type === "login") {
      showToast("Welcome, " + session.name + "!");
    }
  }

  function logout() {
    Auth.logout();
    closeModal();
    location.hash = "";
  }

  // ==================== NAVIGATION ====================
  function viewFromHash() {
    const name = location.hash.replace("#", "");
    return VIEWS[name] ? name : "dashboard";
  }

  function showView(name) {
    state.view = name;
    $$("[data-panel]").forEach((panel) => { panel.hidden = panel.dataset.panel !== name; });
    $$("[data-view]").forEach((btn) => {
      if (btn.dataset.view === name) btn.setAttribute("aria-current", "page");
      else btn.removeAttribute("aria-current");
    });
    dom.pageTitle.textContent = VIEWS[name].title;
    dom.pageSubtitle.textContent = VIEWS[name].subtitle;
    document.title = VIEWS[name].title + " | Employee Management System";
  }

  function goTo(name) {
    if (location.hash === "#" + name) showView(name);
    else location.hash = name;
  }

  // ==================== RENDER: DASHBOARD ====================
  function renderDashboard(report) {
    dom.statTotal.textContent = report.total;
    dom.statActive.textContent = report.active;
    dom.statDepts.textContent = report.departmentsInUse;
    dom.statAverage.textContent = inr(report.averageSalary);

    const maxCount = Math.max(1, ...report.departments.map((d) => d.count));
    dom.deptBars.innerHTML = report.departments.map((d) => `
      <div class="bar-row">
        <span class="bar-label">${esc(d.name)}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${(d.count / maxCount) * 100}%"></div></div>
        <span class="bar-value">${d.count}</span>
      </div>`).join("");

    const percent = report.total ? Math.round((report.active / report.total) * 100) : 0;
    dom.donut.style.setProperty("--p", percent);
    dom.donutLabel.textContent = percent + "%";
    dom.legendActive.textContent = report.active + " active";
    dom.legendInactive.textContent = report.inactive + " inactive";

    dom.recentList.innerHTML = report.recent.length
      ? report.recent.map((e) => `
        <li class="list-item">
          <div class="avatar">${esc(initials(e.name))}</div>
          <div class="grow">
            <div class="title">${esc(e.name)}</div>
            <div class="meta">${esc(e.position)} · ${esc(e.department)}</div>
          </div>
          <div class="meta">${esc(formatDate(e.joined))}</div>
        </li>`).join("")
      : `<li class="muted">No employees yet. Add your first employee from the Employees tab.</li>`;
  }

  // ==================== RENDER: EMPLOYEES ====================
  const SORTERS = {
    name: (a, b) => a.name.localeCompare(b.name),
    id: (a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }),
    salaryDesc: (a, b) => b.salary - a.salary,
    salaryAsc: (a, b) => a.salary - b.salary,
    newest: (a, b) => (b.joined || "").localeCompare(a.joined || ""),
  };

  function filteredEmployees(all) {
    const query = state.search.trim().toLowerCase();
    return all
      .filter((e) => {
        const matchesText = !query || [e.name, e.id, e.email, e.position].some((v) => v.toLowerCase().includes(query));
        const matchesDept = !state.dept || e.department === state.dept;
        const matchesStatus = !state.status || e.status === state.status;
        return matchesText && matchesDept && matchesStatus;
      })
      .sort(SORTERS[state.sort] || SORTERS.name);
  }

  function renderEmployees(all) {
    const list = filteredEmployees(all);
    dom.resultCount.textContent = `Showing ${list.length} of ${all.length} employee${all.length === 1 ? "" : "s"}`;

    if (!list.length) {
      dom.employeeTable.innerHTML = `<tr><td colspan="8"><div class="empty-state">${
        all.length ? "No employees match your search or filters." : "No employees yet — click “Add Employee” to create the first one."
      }</div></td></tr>`;
      return;
    }

    dom.employeeTable.innerHTML = list.map((e) => `
      <tr>
        <td>
          <div class="employee">
            <div class="avatar">${esc(initials(e.name))}</div>
            <div><strong>${esc(e.name)}</strong><br><small>${esc(e.email)}</small></div>
          </div>
        </td>
        <td>${esc(e.id)}</td>
        <td>${esc(e.department)}</td>
        <td>${esc(e.position)}</td>
        <td>${inr(e.salary)}</td>
        <td>${esc(formatDate(e.joined))}</td>
        <td><span class="status ${e.status === "Active" ? "is-active" : "is-inactive"}">${esc(e.status)}</span></td>
        <td>
          <button class="action-btn edit" data-action="edit" data-id="${esc(e.id)}" aria-label="Edit ${esc(e.name)}">✏️ Edit</button>
          <button class="action-btn delete" data-action="delete" data-id="${esc(e.id)}" aria-label="Delete ${esc(e.name)}">🗑️ Delete</button>
        </td>
      </tr>`).join("");
  }

  // ==================== RENDER: DEPARTMENTS ====================
  function renderDepartments(report) {
    dom.deptGrid.innerHTML = report.departments.map((d) => `
      <article class="card dept-card">
        <div class="dept-head">
          <h3>${esc(d.name)}</h3>
          <span class="dept-count">${d.count} ${d.count === 1 ? "employee" : "employees"}</span>
        </div>
        <div class="dept-metrics">
          <div><small>Active</small><strong>${d.active}</strong></div>
          <div><small>Avg. salary</small><strong>${inr(d.average)}</strong></div>
          <div><small>Total salary</small><strong>${inr(d.payroll)}</strong></div>
          <div><small>Payroll share</small><strong>${d.share.toFixed(0)}%</strong></div>
        </div>
        <button class="btn btn-ghost" data-dept="${esc(d.name)}">View employees →</button>
      </article>`).join("");
  }

  // ==================== RENDER: REPORTS ====================
  function renderReports(report) {
    dom.repPayroll.textContent = inr(report.activePayroll);
    dom.repAverage.textContent = inr(report.averageSalary);
    dom.repHighest.textContent = report.highest ? inr(report.highest.salary) : "—";
    dom.repLowest.textContent = report.lowest ? inr(report.lowest.salary) : "—";

    const maxAvg = Math.max(1, ...report.departments.map((d) => d.average));
    dom.repDeptBars.innerHTML = report.departments.map((d) => `
      <div class="bar-row">
        <span class="bar-label">${esc(d.name)}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${(d.average / maxAvg) * 100}%"></div></div>
        <span class="bar-value">${inr(d.average)}</span>
      </div>`).join("");

    dom.repTop.innerHTML = report.topEarners.length
      ? report.topEarners.map((e, i) => `
        <li class="list-item">
          <span class="rank">${i + 1}</span>
          <div class="grow">
            <div class="title">${esc(e.name)}</div>
            <div class="meta">${esc(e.position)} · ${esc(e.department)}</div>
          </div>
          <strong>${inr(e.salary)}</strong>
        </li>`).join("")
      : `<li class="muted">No data yet.</li>`;
  }

  function renderAll() {
    if (dom.app.hidden) return;
    const all = EmployeeStore.all();
    const report = Reports.summarize(all);
    renderDashboard(report);
    renderEmployees(all);
    renderDepartments(report);
    renderReports(report);
    dom.themeSelect.value = Theme.get();
  }

  // ==================== MODALS ====================
  function openModal(modal) {
    lastFocus = document.activeElement;
    modal.classList.add("show");
  }

  function closeModal() {
    $$(".modal.show").forEach((m) => m.classList.remove("show"));
    state.editingId = null;
    if (lastFocus && lastFocus.focus) lastFocus.focus();
    lastFocus = null;
  }

  function openEmployeeModal(id = null) {
    state.editingId = id;
    dom.formError.hidden = true;
    dom.form.reset();

    if (id === null) {
      dom.modalTitle.textContent = "Add Employee";
      dom.submitBtn.textContent = "Add Employee";
      dom.fId.value = EmployeeStore.nextId();
      dom.fJoined.value = Utils.today();
    } else {
      const emp = EmployeeStore.find(id);
      if (!emp) { showToast("That employee no longer exists."); renderAll(); return; }
      dom.modalTitle.textContent = "Edit Employee";
      dom.submitBtn.textContent = "Save Changes";
      dom.fId.value = emp.id;
      dom.fName.value = emp.name;
      dom.fEmail.value = emp.email;
      dom.fDept.value = emp.department;
      dom.fPosition.value = emp.position;
      dom.fSalary.value = emp.salary;
      dom.fStatus.value = emp.status;
      dom.fJoined.value = emp.joined;
    }
    openModal(dom.modal);
    dom.fName.focus();
  }

  function handleEmployeeSubmit(event) {
    event.preventDefault();
    const data = {
      id: dom.fId.value,
      name: dom.fName.value,
      email: dom.fEmail.value,
      department: dom.fDept.value,
      position: dom.fPosition.value,
      salary: dom.fSalary.value,
      status: dom.fStatus.value,
      joined: dom.fJoined.value,
    };
    const editing = state.editingId !== null;
    if (dom.fSalary.value.trim() === "") {
      dom.formError.textContent = "Please enter a salary.";
      dom.formError.hidden = false;
      return;
    }
    const result = editing ? EmployeeStore.update(state.editingId, data) : EmployeeStore.add(data);

    if (!result.ok) {
      dom.formError.textContent = result.error;
      dom.formError.hidden = false;
      return;
    }
    closeModal();
    renderAll();
    showToast(editing ? "Employee updated successfully!" : "Employee added successfully!");
  }

  /** Promise-based replacement for window.confirm(). */
  function confirmDialog({ title, text, okLabel = "Delete" }) {
    return new Promise((resolve) => {
      dom.confirmTitle.textContent = title;
      dom.confirmText.textContent = text;
      dom.confirmOk.textContent = okLabel;
      openModal(dom.confirmModal);
      dom.confirmCancel.focus();

      const finish = (answer) => {
        dom.confirmOk.removeEventListener("click", onOk);
        dom.confirmCancel.removeEventListener("click", onCancel);
        dom.confirmModal.removeEventListener("ems:dismiss", onCancel);
        if (dom.confirmModal.classList.contains("show")) closeModal();
        resolve(answer);
      };
      const onOk = () => finish(true);
      const onCancel = () => finish(false);
      dom.confirmOk.addEventListener("click", onOk);
      dom.confirmCancel.addEventListener("click", onCancel);
      dom.confirmModal.addEventListener("ems:dismiss", onCancel);
    });
  }

  async function deleteEmployee(id) {
    const emp = EmployeeStore.find(id);
    if (!emp) return;
    const yes = await confirmDialog({
      title: "Delete employee?",
      text: `${emp.name} (${emp.id}) will be removed permanently. This cannot be undone.`,
    });
    if (!yes) return;
    EmployeeStore.remove(id);
    renderAll();
    showToast("Employee deleted successfully!");
  }

  // ==================== EVENTS ====================
  function populateDepartmentSelects() {
    const options = EmployeeStore.DEPARTMENTS.map((d) => `<option value="${esc(d)}">${esc(d)}</option>`).join("");
    dom.deptFilter.innerHTML = `<option value="">All Departments</option>` + options;
    dom.fDept.innerHTML = `<option value="">Select department</option>` + options;
  }

  function dismissTopModal() {
    const open = $(".modal.show");
    if (!open) return;
    if (open === dom.confirmModal) open.dispatchEvent(new Event("ems:dismiss"));
    else closeModal();
  }

  function bindEvents() {
    // navigation
    $$("[data-view]").forEach((btn) => btn.addEventListener("click", () => goTo(btn.dataset.view)));
    $$("[data-goto]").forEach((btn) => btn.addEventListener("click", () => goTo(btn.dataset.goto)));
    window.addEventListener("hashchange", () => { if (!dom.app.hidden) showView(viewFromHash()); });
    window.addEventListener("ems:auth-change", syncAuth);
    window.addEventListener("storage", () => { if (!dom.app.hidden) renderAll(); });

    // top bar
    $("#logoutBtn").addEventListener("click", logout);
    $("#bellBtn").addEventListener("click", () => {
      const report = Reports.summarize(EmployeeStore.all());
      showToast(report.inactive
        ? `${report.inactive} inactive employee${report.inactive === 1 ? "" : "s"} may need review.`
        : "All employees are active — nothing needs attention.");
    });

    // employees view
    $("#addEmployeeBtn").addEventListener("click", () => openEmployeeModal());
    dom.searchInput.addEventListener("input", () => { state.search = dom.searchInput.value; renderEmployees(EmployeeStore.all()); });
    dom.deptFilter.addEventListener("change", () => { state.dept = dom.deptFilter.value; renderEmployees(EmployeeStore.all()); });
    dom.statusFilter.addEventListener("change", () => { state.status = dom.statusFilter.value; renderEmployees(EmployeeStore.all()); });
    dom.sortSelect.addEventListener("change", () => { state.sort = dom.sortSelect.value; renderEmployees(EmployeeStore.all()); });
    $("#clearFiltersBtn").addEventListener("click", () => {
      state.search = ""; state.dept = ""; state.status = ""; state.sort = "name";
      dom.searchInput.value = ""; dom.deptFilter.value = ""; dom.statusFilter.value = ""; dom.sortSelect.value = "name";
      renderEmployees(EmployeeStore.all());
    });
    dom.employeeTable.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-action]");
      if (!btn) return;
      if (btn.dataset.action === "edit") openEmployeeModal(btn.dataset.id);
      else if (btn.dataset.action === "delete") deleteEmployee(btn.dataset.id);
    });

    // departments view -> jump to a filtered employee list
    dom.deptGrid.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-dept]");
      if (!btn) return;
      state.dept = btn.dataset.dept;
      dom.deptFilter.value = state.dept;
      renderEmployees(EmployeeStore.all());
      goTo("employees");
    });

    // export / print
    $$("[data-export]").forEach((btn) => btn.addEventListener("click", () => {
      Utils.download("employees-" + Utils.today() + ".csv", EmployeeStore.toCSV(), "text/csv");
      showToast("Employee list exported as CSV.");
    }));
    $("#printBtn").addEventListener("click", () => window.print());

    // settings
    dom.themeSelect.addEventListener("change", () => Theme.set(dom.themeSelect.value));
    window.addEventListener("ems:theme-change", () => { dom.themeSelect.value = Theme.get(); });
    $("#resetDemoBtn").addEventListener("click", async () => {
      const yes = await confirmDialog({ title: "Reset to demo data?", text: "All current employees will be replaced with the 5 sample employees.", okLabel: "Reset data" });
      if (!yes) return;
      EmployeeStore.resetDemo();
      renderAll();
      showToast("Demo data restored.");
    });
    $("#clearAllBtn").addEventListener("click", async () => {
      const yes = await confirmDialog({ title: "Delete ALL employees?", text: "Every employee record will be removed permanently. Consider exporting a CSV first.", okLabel: "Delete everything" });
      if (!yes) return;
      EmployeeStore.clearAll();
      renderAll();
      showToast("All employee records deleted.");
    });

    // modal
    dom.form.addEventListener("submit", handleEmployeeSubmit);
    $$("[data-close-modal]").forEach((btn) => btn.addEventListener("click", dismissTopModal));
    $$(".modal").forEach((modal) => modal.addEventListener("mousedown", (event) => {
      if (event.target === modal) dismissTopModal();
    }));
    document.addEventListener("keydown", (event) => { if (event.key === "Escape") dismissTopModal(); });
  }

  // ==================== INIT ====================
  populateDepartmentSelects();
  bindEvents();
  syncAuth();
})();
