/* ====================================================================
   EMS — REPORTS MODULE
   Pure calculations over the employee list (no DOM). Used by the
   dashboard, departments view, reports view and the admin page.
   ==================================================================== */

const Reports = (() => {
  function summarize(list) {
    const total = list.length;
    const active = list.filter((e) => e.status === "Active");
    const activePayroll = active.reduce((sum, e) => sum + e.salary, 0);
    const allPayroll = list.reduce((sum, e) => sum + e.salary, 0);

    // Known departments first (stable order), then any custom ones found in the data.
    const names = [...EmployeeStore.DEPARTMENTS];
    list.forEach((e) => { if (e.department && !names.includes(e.department)) names.push(e.department); });

    const departments = names.map((name) => {
      const members = list.filter((e) => e.department === name);
      const payroll = members.reduce((sum, e) => sum + e.salary, 0);
      return {
        name,
        count: members.length,
        active: members.filter((e) => e.status === "Active").length,
        payroll,
        average: members.length ? payroll / members.length : 0,
        share: allPayroll ? (payroll / allPayroll) * 100 : 0,
      };
    });

    const bySalary = [...list].sort((a, b) => b.salary - a.salary);
    const recent = [...list]
      .map((e, i) => ({ e, i }))
      .sort((a, b) => (b.e.joined || "").localeCompare(a.e.joined || "") || b.i - a.i)
      .map((x) => x.e)
      .slice(0, 5);

    return {
      total,
      active: active.length,
      inactive: total - active.length,
      activePayroll,
      allPayroll,
      averageSalary: total ? allPayroll / total : 0,
      departments,
      departmentsInUse: departments.filter((d) => d.count > 0).length,
      topEarners: bySalary.slice(0, 5),
      highest: bySalary[0] || null,
      lowest: bySalary[bySalary.length - 1] || null,
      recent,
    };
  }

  return { summarize };
})();
