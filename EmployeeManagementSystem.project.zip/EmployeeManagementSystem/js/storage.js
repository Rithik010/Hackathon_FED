/* ====================================================================
   EMS — EMPLOYEE STORE
   All employee data lives here, persisted in localStorage.
   Employees are looked up by their Employee ID (never by array index),
   so editing / deleting is safe even when the list is filtered.
   ==================================================================== */

const EmployeeStore = (() => {
  const KEY = "ems.employees.v1";
  const LEGACY_KEY = "employees"; // key used by the original single-file version
  const DEPARTMENTS = ["IT", "HR", "Finance", "Marketing", "Operations"];
  const STATUSES = ["Active", "Inactive"];

  function seed() {
    return [
      { id: "EMP001", name: "Rahul Sharma", email: "rahul@example.com", department: "IT", position: "Software Developer", salary: 65000, status: "Active", joined: "2023-04-12" },
      { id: "EMP002", name: "Priya Reddy", email: "priya@example.com", department: "HR", position: "HR Manager", salary: 55000, status: "Active", joined: "2022-09-01" },
      { id: "EMP003", name: "Arjun Kumar", email: "arjun@example.com", department: "Finance", position: "Accountant", salary: 48000, status: "Active", joined: "2024-01-15" },
      { id: "EMP004", name: "Sneha Patel", email: "sneha@example.com", department: "Marketing", position: "Marketing Executive", salary: 42000, status: "Inactive", joined: "2023-07-20" },
      { id: "EMP005", name: "Vikram Singh", email: "vikram@example.com", department: "Operations", position: "Operations Manager", salary: 70000, status: "Active", joined: "2021-11-08" },
    ];
  }

  function normalize(raw) {
    return {
      id: String(raw.id ?? "").trim(),
      name: String(raw.name ?? "").trim(),
      email: String(raw.email ?? "").trim(),
      department: String(raw.department ?? "").trim(),
      position: String(raw.position ?? "").trim(),
      salary: Math.max(0, Number(raw.salary) || 0),
      status: raw.status === "Active" ? "Active" : "Inactive",
      joined: raw.joined || Utils.today(),
    };
  }

  function write(list) {
    try {
      localStorage.setItem(KEY, JSON.stringify(list));
      return true;
    } catch (error) {
      return false;
    }
  }

  function all() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw !== null) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.map(normalize);
      }
      const legacy = localStorage.getItem(LEGACY_KEY);
      if (legacy) {
        const parsed = JSON.parse(legacy);
        if (Array.isArray(parsed) && parsed.length) {
          const migrated = parsed.map(normalize);
          write(migrated);
          return migrated;
        }
      }
    } catch (error) { /* fall through to seed data */ }
    const data = seed();
    write(data);
    return data;
  }

  function validate(emp, list, ignoreId) {
    if (!emp.name) return "Please enter the employee's name.";
    if (!emp.id) return "Please enter an Employee ID.";
    if (!/^\S+@\S+\.\S+$/.test(emp.email)) return "Please enter a valid email address.";
    if (!emp.department) return "Please choose a department.";
    if (!emp.position) return "Please enter a position.";
    if (!(emp.salary >= 0) || !Number.isFinite(emp.salary)) return "Please enter a valid salary.";
    const idTaken = list.some(
      (e) => e.id.toLowerCase() === emp.id.toLowerCase() && e.id !== ignoreId
    );
    if (idTaken) return `Employee ID ${emp.id} is already in use.`;
    return "";
  }

  function add(input) {
    const list = all();
    const emp = normalize(input);
    const error = validate(emp, list, null);
    if (error) return { ok: false, error };
    list.push(emp);
    return write(list) ? { ok: true, employee: emp } : { ok: false, error: "Could not save — browser storage is unavailable." };
  }

  function update(originalId, input) {
    const list = all();
    const index = list.findIndex((e) => e.id === originalId);
    if (index === -1) return { ok: false, error: "That employee no longer exists." };
    const emp = normalize({ ...input, joined: input.joined || list[index].joined });
    const error = validate(emp, list, originalId);
    if (error) return { ok: false, error };
    list[index] = emp;
    return write(list) ? { ok: true, employee: emp } : { ok: false, error: "Could not save — browser storage is unavailable." };
  }

  function remove(id) {
    const list = all();
    const next = list.filter((e) => e.id !== id);
    if (next.length === list.length) return false;
    return write(next);
  }

  function find(id) {
    return all().find((e) => e.id === id) || null;
  }

  /** Suggest the next free ID, e.g. EMP006. */
  function nextId() {
    const max = all().reduce((highest, e) => {
      const match = /(\d+)$/.exec(e.id);
      return match ? Math.max(highest, Number(match[1])) : highest;
    }, 0);
    return "EMP" + String(max + 1).padStart(3, "0");
  }

  function resetDemo() { return write(seed()); }
  function clearAll() { return write([]); }

  /** CSV text. Cells starting with = + - @ are prefixed to block spreadsheet formula injection. */
  function toCSV(list = all()) {
    const header = ["Employee ID", "Name", "Email", "Department", "Position", "Salary", "Status", "Joined"];
    const cell = (value) => {
      let text = String(value ?? "");
      if (/^[=+\-@]/.test(text)) text = "'" + text;
      return /[",\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
    };
    const rows = list.map((e) => [e.id, e.name, e.email, e.department, e.position, e.salary, e.status, e.joined].map(cell).join(","));
    return [header.join(","), ...rows].join("\r\n");
  }

  return { DEPARTMENTS, STATUSES, all, find, add, update, remove, nextId, resetDemo, clearAll, toCSV };
})();
