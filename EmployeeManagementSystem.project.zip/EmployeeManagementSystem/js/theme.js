/* ====================================================================
   EMS — THEME MODULE
   Light / dark theme. Defaults to the OS preference on first run, then
   remembers the user's choice. Loaded in <head> so there is no flash.
   Any element with [data-theme-toggle] becomes a theme switch button.
   ==================================================================== */

const Theme = (() => {
  const KEY = "ems.theme";

  function get() {
    try {
      const saved = localStorage.getItem(KEY);
      if (saved === "dark" || saved === "light") return saved;
    } catch (error) { /* storage unavailable */ }
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }

  function apply(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
      btn.textContent = theme === "dark" ? "☀️" : "🌙";
      btn.title = theme === "dark" ? "Switch to light mode" : "Switch to dark mode";
      btn.setAttribute("aria-label", btn.title);
    });
    window.dispatchEvent(new CustomEvent("ems:theme-change", { detail: theme }));
  }

  function set(theme) {
    try { localStorage.setItem(KEY, theme); } catch (error) { /* ignore */ }
    apply(theme);
  }

  function toggle() {
    const next = get() === "dark" ? "light" : "dark";
    set(next);
    return next;
  }

  document.documentElement.setAttribute("data-theme", get());

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
      btn.addEventListener("click", toggle);
    });
    apply(get());
  });

  return { get, set, toggle };
})();
