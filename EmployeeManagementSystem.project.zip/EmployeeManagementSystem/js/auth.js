/* ====================================================================
   EMS — AUTH MODULE
   Local demo authentication (no server):
     • "user"  accounts: demo HR account + anyone who signs up
     • "admin" account : demo administrator
   Wires up: the auth gate on index.html, login.html and admin-login.html.
   (admin.html guards itself in js/admin.js.)

   NOTE: this is a front-end demo. Credentials live in the browser's
   localStorage, so it is NOT real security. For production, replace
   this module with calls to a real backend and never store passwords
   in the browser.
   ==================================================================== */

const Auth = (() => {
  const SESSION_KEY = "ems.session";
  const USERS_KEY = "ems.users";

  const DEMO = {
    user: { email: "hr@ems.app", password: "ems2026", name: "HR Manager" },
    admin: { email: "admin@ems.app", password: "ems2026", name: "EMS Admin" },
  };

  function parse(raw, fallback) {
    try {
      const value = JSON.parse(raw);
      return value ?? fallback;
    } catch (error) {
      return fallback;
    }
  }

  function read(storage, key) {
    try { return storage.getItem(key); } catch (error) { return null; }
  }

  // ---------- sessions ----------
  function getSession() {
    return parse(read(localStorage, SESSION_KEY), null) || parse(read(sessionStorage, SESSION_KEY), null);
  }

  function setSession(role, account, remember = true) {
    const payload = JSON.stringify({ role, email: account.email, name: account.name });
    clearSession();
    try { (remember ? localStorage : sessionStorage).setItem(SESSION_KEY, payload); } catch (error) { /* ignore */ }
  }

  function clearSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (error) { /* ignore */ }
    try { sessionStorage.removeItem(SESSION_KEY); } catch (error) { /* ignore */ }
  }

  // ---------- accounts ----------
  function getUsers() {
    const users = parse(read(localStorage, USERS_KEY), []);
    return Array.isArray(users) ? users : [];
  }

  function findUser(email) {
    const wanted = String(email).trim().toLowerCase();
    const registered = getUsers().find((u) => u.email === wanted);
    if (registered) return registered;
    return wanted === DEMO.user.email ? DEMO.user : null;
  }

  /** Returns an error message, or "" on success. */
  function register(name, email, password) {
    const cleanName = String(name).trim();
    const cleanEmail = String(email).trim().toLowerCase();
    if (cleanName.length < 2) return "Please enter your name.";
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) return "Please enter a valid email address.";
    if (findUser(cleanEmail) || cleanEmail === DEMO.admin.email) return "An account with this email already exists.";
    if (String(password).length < 6) return "Your password must be at least 6 characters.";
    const users = getUsers();
    users.push({ name: cleanName, email: cleanEmail, password });
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } catch (error) {
      return "Could not save your account — browser storage is unavailable.";
    }
    return "";
  }

  /** Returns the matching account, or null. */
  function login(role, email, password) {
    const account = role === "admin"
      ? (String(email).trim().toLowerCase() === DEMO.admin.email ? DEMO.admin : null)
      : findUser(email);
    return account && account.password === password ? account : null;
  }

  function removeUser(email) {
    const users = getUsers().filter((u) => u.email !== email);
    try { localStorage.setItem(USERS_KEY, JSON.stringify(users)); } catch (error) { /* ignore */ }
  }

  /** Every account the admin can see. */
  function listAccounts() {
    return [
      { ...DEMO.admin, type: "Administrator", removable: false },
      { ...DEMO.user, type: "Demo user", removable: false },
      ...getUsers().map((u) => ({ ...u, type: "Registered user", removable: true })),
    ];
  }

  function logout() {
    clearSession();
    window.dispatchEvent(new CustomEvent("ems:auth-change", { detail: { type: "logout" } }));
  }

  // ---------- page wiring ----------
  function showMessage(el, text, kind) {
    if (!el) return;
    el.textContent = text;
    el.hidden = !text;
    el.classList.toggle("is-error", kind === "error");
    el.classList.toggle("is-success", kind === "success");
  }

  function bindPasswordToggles() {
    document.querySelectorAll("[data-toggle-password]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const input = document.getElementById(btn.dataset.togglePassword);
        if (!input) return;
        const reveal = input.type === "password";
        input.type = reveal ? "text" : "password";
        btn.textContent = reveal ? "Hide" : "Show";
        btn.setAttribute("aria-pressed", String(reveal));
      });
    });
  }

  function showGatePanel(name) {
    document.querySelectorAll("[data-auth-panel]").forEach((panel) => {
      panel.hidden = panel.dataset.authPanel !== name;
    });
    document.querySelectorAll("[data-auth-view]").forEach((btn) => {
      const active = btn.dataset.authView === name;
      btn.classList.toggle("is-active", active);
      btn.setAttribute("aria-selected", String(active));
    });
  }

  function initGate() {
    const loginForm = document.getElementById("gateLoginForm");
    const signupForm = document.getElementById("gateSignupForm");
    if (!loginForm || !signupForm) return;

    const loginMsg = document.getElementById("gateLoginMsg");
    const signupMsg = document.getElementById("gateSignupMsg");

    document.querySelectorAll("[data-auth-view]").forEach((btn) => {
      btn.addEventListener("click", () => {
        showMessage(loginMsg, "", "");
        showMessage(signupMsg, "", "");
        showGatePanel(btn.dataset.authView);
      });
    });

    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const email = document.getElementById("gateLoginEmail").value;
      const password = document.getElementById("gateLoginPassword").value;
      const remember = document.getElementById("gateRemember").checked;
      const account = login("user", email, password);
      if (!account) {
        showMessage(loginMsg, "That email or password does not match an account.", "error");
        return;
      }
      setSession("user", account, remember);
      loginForm.reset();
      showMessage(loginMsg, "", "");
      window.dispatchEvent(new CustomEvent("ems:auth-change", { detail: { type: "login" } }));
    });

    signupForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const password = document.getElementById("gateSignupPassword").value;
      const confirm = document.getElementById("gateSignupConfirm").value;
      if (password !== confirm) {
        showMessage(signupMsg, "Passwords do not match.", "error");
        return;
      }
      const email = document.getElementById("gateSignupEmail").value.trim().toLowerCase();
      const error = register(document.getElementById("gateSignupName").value, email, password);
      if (error) {
        showMessage(signupMsg, error, "error");
        return;
      }
      signupForm.reset();
      showGatePanel("login");
      document.getElementById("gateLoginEmail").value = email;
      document.getElementById("gateLoginPassword").value = "";
      showMessage(loginMsg, "Account created. Please sign in to continue.", "success");
    });

    const forgot = document.getElementById("gateForgot");
    if (forgot) {
      forgot.addEventListener("click", () => {
        const email = document.getElementById("gateLoginEmail").value.trim();
        if (!email) {
          showMessage(loginMsg, "Enter your email first, then choose Forgot password.", "error");
        } else {
          showMessage(loginMsg, "Demo mode: there is no email service. Please contact your administrator to reset your password.", "success");
        }
      });
    }
  }

  function initLoginPage() {
    const form = document.getElementById("loginForm");
    if (!form) return;
    const role = document.body.dataset.authRole === "admin" ? "admin" : "user";
    const home = role === "admin" ? "admin.html" : "index.html";
    const message = document.getElementById("loginError");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    const session = getSession();
    if (session && (session.role === role || (role === "user" && session.role === "admin"))) {
      window.location.replace(home);
      return;
    }

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const account = login(role, emailInput.value, passwordInput.value);
      if (!account) {
        showMessage(message, "That email or password does not match an account.", "error");
        passwordInput.focus();
        return;
      }
      const remember = document.getElementById("remember");
      setSession(role, account, remember ? remember.checked : true);
      window.location.href = home;
    });
  }

  bindPasswordToggles();
  initGate();
  initLoginPage();

  return { getSession, logout, listAccounts, removeUser, DEMO };
})();
