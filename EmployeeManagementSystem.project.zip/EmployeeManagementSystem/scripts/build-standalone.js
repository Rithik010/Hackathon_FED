/* Builds standalone/index.html — the whole employee app (HTML + CSS + JS)
   inlined into ONE file you can email or open anywhere.
   Run: npm run build:standalone
   The admin pages are not part of the standalone file, so links to them
   (marked data-standalone-hide) are removed. */
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
let html = fs.readFileSync(path.join(root, "index.html"), "utf8");

// Inline stylesheets
html = html.replace(/<link rel="stylesheet" href="(css\/[^"]+)" \/>/g, (_, href) => {
  const css = fs.readFileSync(path.join(root, href), "utf8");
  return `<style>\n/* ${href} */\n${css}\n</style>`;
});

// Inline scripts
html = html.replace(/<script src="(js\/[^"]+)"><\/script>/g, (_, src) => {
  const js = fs.readFileSync(path.join(root, src), "utf8").replace(/<\/script/gi, "<\\/script");
  return `<script>\n/* ${src} */\n${js}\n</script>`;
});

// Remove links to pages that are not in the standalone file
html = html.replace(/<a\b[^>]*data-standalone-hide[^>]*>[\s\S]*?<\/a>/g, "");

// Inline the favicon
const icon = fs.readFileSync(path.join(root, "assets/icons/app-icon.svg"));
html = html.replace('href="assets/icons/app-icon.svg"', `href="data:image/svg+xml;base64,${icon.toString("base64")}"`);

fs.mkdirSync(path.join(root, "standalone"), { recursive: true });
fs.writeFileSync(path.join(root, "standalone/index.html"), html);
console.log("Wrote standalone/index.html (" + Math.round(html.length / 1024) + " KB)");
