/* Copies the web app into ./www so Capacitor only bundles what it needs
   (and not node_modules, electron/, etc.).  Run: npm run build:web */
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const out = path.join(root, "www");
const include = ["index.html", "login.html", "admin-login.html", "admin.html", "css", "js", "assets"];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const item of include) {
  fs.cpSync(path.join(root, item), path.join(out, item), { recursive: true });
}
console.log("Web app copied to www/");
