/* ====================================================================
   EMS — ELECTRON MAIN PROCESS
   Loads the same HTML/CSS/JS front-end used on the web, packaged as
   a native desktop window for Windows, macOS and Linux.
   ==================================================================== */

const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

let mainWindow = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 380,
    minHeight: 640,
    backgroundColor: "#0f172a",
    title: "Employee Management System",
    icon: path.join(__dirname, "..", "assets", "icons", "app-icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    show: false,
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "..", "index.html"));

  // Show only once the page is ready to avoid a white flash.
  mainWindow.once("ready-to-show", () => mainWindow.show());

  // Open any external (http/https) links in the OS browser, not inside the app.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.whenReady().then(createMainWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
});
